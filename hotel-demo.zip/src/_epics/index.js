import { combineEpics } from 'redux-observable';
import searchresultepic from '../modules/SearchResult/ducks/epic'

export const rootEpic = combineEpics(
  searchresultepic
);

