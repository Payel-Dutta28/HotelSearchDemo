import searchBtnIcon from "../assets/search_Btn.svg";

const icons = {
  searchBtnIcon
};

export default icons;
