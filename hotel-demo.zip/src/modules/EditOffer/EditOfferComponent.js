import React from 'react';

export const EditOfferComponent = props => {  
    return(
       <div>Edit OFfer</div>
    )
}