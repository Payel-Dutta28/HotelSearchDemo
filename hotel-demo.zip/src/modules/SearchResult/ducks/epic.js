import "rxjs";
import { Observable } from "rxjs";
import { ajax } from "rxjs/ajax";

import { ofType } from "redux-observable";
import { map, mergeMap } from "rxjs/operators";

import { LOAD_HOTELS } from "./constant";
import * as hotelResultAction from "./action";
import { BrowserRouter as Router, Route } from "react-router-dom";

import { createBrowserHistory } from "history";

const url = "https://api.myjson.com/bins/17rb24";
// const url = "https://api.myjson.com/bins/djduw";

/**
 * checkout epic.
 * @param action$
 * @param store
 * @returns {any|*|Observable}
 */
const searchresultepic = (action$, store) =>
  action$.pipe(
    ofType(LOAD_HOTELS),
    mergeMap(action =>
      ajax
        .getJSON(url)
        .pipe(
          map(response =>
            hotelResultAction.fetchHotelSearchResultSuccess(response)
          )
        )
    )
  );
export default searchresultepic;
