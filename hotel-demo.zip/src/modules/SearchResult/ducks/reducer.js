import {
  ADDITION,
  LOAD_HOTELS,
  LOAD_HOTELS_SUCCESS,
  LOAD_HOTELS_ERROR
} from "./constant";

const initialState = {
  adults: 0,
  children: 0,
  rooms: 0,
  hotelSearchResult: [],
  isLoading: false
};
export default function operationReducer(state = initialState, action) {
  switch (action.type) {
    case ADDITION:
      return {
        ...state,
        adults: state.adults + 1
      };
    case LOAD_HOTELS:
      return {
        ...state,
        isLoading: true
      };
    case LOAD_HOTELS_SUCCESS:
      return {
        ...state,
        hotelSearchResult: action.payload,
        isLoading: false
      };
    case LOAD_HOTELS_ERROR:
      return {
        ...state,
        offerSearchResult: [],
        isLoading: false
      };
    default:
      return state;
  }
}
