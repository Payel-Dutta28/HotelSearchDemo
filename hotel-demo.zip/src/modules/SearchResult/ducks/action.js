import {
  ADDITION,
  LOAD_HOTELS,
  LOAD_HOTELS_SUCCESS,
  LOAD_HOTELS_ERROR
} from "./constant";
export function addition() {
  return {
    type: ADDITION
  };
}
export function fetchHotelSearchResult(requestParam) {
  console.log("fetch hotel list action", requestParam);
  return {
    type: LOAD_HOTELS,
    payload: requestParam
  };
}

export function fetchHotelSearchResultSuccess(hotelList) {
  console.log(hotelList);
  return {
    type: LOAD_HOTELS_SUCCESS,
    payload: hotelList
  };
}

export function fetchHotelSearchResultFailure(message) {
  return {
    type: LOAD_HOTELS_ERROR,
    payload: message
  };
}
