import React from "react";

import "./ducks/style.css";
import { InlineDatePicker } from "material-ui-pickers/DatePicker";
import MomentUtils from "material-ui-pickers/utils/moment-utils";
import MuiPickersUtilsProvider from "material-ui-pickers/utils/MuiPickersUtilsProvider";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Icon from "@material-ui/core/Icon";
import IconButton from "@material-ui/core/IconButton";
import AddIcon from "@material-ui/icons/Add";
import MinusIcon from "@material-ui/icons/Remove";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import icons from "../../_styles/icons";
import { withStyles } from "@material-ui/core/styles";
import { NavLink } from "react-router-dom";

const sideBar = {
  backgroundColor: "#0964a9",
  height: "100%",
  borderRadius: "5px 0px 0px 5px"
};
const styles = theme => ({
  searchBtn: {
    height: "50px",
    width: "220px",
    marginLeft: "50px",
    marginTop: "50px",
    marginBottom: "50px"
  }
});

// const SearchButton = withStyles(styles)(props => {
//   const { classes } = props;
//   console.log(" state", this.state);
//   return (
//     // <NavLink to="/hotelsearchresult">
//     //   <Button
//     //     variant="contained"
//     //     color="primary"
//     //     className={classes.searchBtn}
//     //     onClick={props.action.fetchHotelSearchResult()}
//     //   >
//     //     <img src={icons.searchBtnIcon} className="search-btn-img" /> Search
//     //   </Button>
//     // </NavLink>
//   );
// });

export class SearchResultComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checkInDate: "2018-09-13",
      checkOutDate: "2018-09-16",
      inputValue: "",
      location: "",
      adults: 0,
      children: 0,
      count: 0
    };
  }

  handleChange = name => event => {
    this.setState({
      location: event.target.value
    });
    console.log("LOCATION in state", this.state.location);
  };

  handleCheckInDateChange = date => {
    this.setState({ checkInDate: date });
  };
  handleCheckOutDateChange = date => {
    this.setState({ checkOutDate: date });
  };
  handleCountChange = (eventName, field) => {
    switch (eventName) {
      case "add": {
        switch (field) {
          case "adults": {
            this.setState({ adults: this.state.adults + 1 });
            return;
          }
          case "children": {
            this.setState({ children: (this.state.children += 1) });
            return;
          }
          case "count": {
            this.setState({ count: (this.state.count += 1) });
            return;
          }
        }
      }
      case "sub": {
        switch (field) {
          case "adults": {
            this.setState({ adults: this.state.adults - 1 });
            return;
          }
          case "children": {
            this.setState({ children: (this.state.children -= 1) });
            return;
          }
          case "count": {
            this.setState({ count: (this.state.count -= 1) });
            return;
          }
        }
      }
    }
  };

  render() {
    const { route, adults, action } = this.props;
    return (
      <div className="search-wrapper">
        <MuiPickersUtilsProvider utils={MomentUtils}>
          <Grid container spacing={0} className="row">
            <Grid item xs={6} className="destination-row">
              <h3>*Destination</h3>
              {/* <TextField
                required
                id="standard-dense"
                // label="Destination"
                
                margin="normal"
                onChange={this.handleChange("name")}
                margin="dense"
                variant="filled"
                className="destination-text-field"
              /> */}
              <input
                type="text"
                name="fname"
                value={this.state.location}
                onChange={this.handleChange("name")}
              />
            </Grid>
            {/* </Grid> */}
            {/* <Grid container spacing={0} className="row"> */}
            <Grid item xs={3}>
              <div className="picker">
                <h3>Check In</h3>
                <InlineDatePicker
                  required
                  keyboard
                  // label="Check In"
                  InputProps={{
                    disableUnderline: true,
                   }}
                  value={this.state.checkInDate}
                  onChange={this.handleCheckInDateChange}
                  format="DD/MM/YYYY"
                  mask={[
                    /\d/,
                    /\d/,
                    "/",
                    /\d/,
                    /\d/,
                    "/",
                    /\d/,
                    /\d/,
                    /\d/,
                    /\d/
                  ]}
                />
              </div>
            </Grid>
            <Grid item xs={3}>
              <div className="picker">
                <h3>Check Out</h3>
                <InlineDatePicker
                  required
                  keyboard
                  // label="Check Out"
                  InputProps={{
                    disableUnderline: true,
                   }}
                  value={this.state.checkOutDate}
                  onChange={this.handleCheckOutDateChange}
                  format="DD/MM/YYYY"
                  mask={[
                    /\d/,
                    /\d/,
                    "/",
                    /\d/,
                    /\d/,
                    "/",
                    /\d/,
                    /\d/,
                    /\d/,
                    /\d/
                  ]}
                />
              </div>
            </Grid>
          </Grid>

          <Grid container spacing={0} className="row">
            <Grid item xs={2}>
              <h3>Adults</h3>
              <div className="incrementer-box">
                <IconButton
                  onClick={() => {
                    this.handleCountChange("add", "adults");
                  }}
                  //onClick={action.addition}
                  aria-label="add"
                >
                  <AddIcon />
                </IconButton>
                {/* <TextField
                  required
                  id="adults"
                  label="Adults"
                  // value={adults}
                  value={this.state.adults}
                  onChange={this.handleChange("name")}
                  margin="normal"
                  variant="filled"
                /> */}
                <input type="text" name="fname" value={this.state.adults} />
                <IconButton
                  aria-label="Delete"
                  onClick={evt => {
                    this.handleCountChange("sub", "adults");
                  }}
                  id="minus"
                >
                  <MinusIcon />
                </IconButton>
              </div>
            </Grid>
            <Grid item xs={2}>
              <h3>Children</h3>
              <div className="incrementer-box">
                <IconButton
                  aria-label="Delete"
                  onClick={() => {
                    this.handleCountChange("add", "children");
                  }}
                >
                  <AddIcon />
                </IconButton>
                {/* <TextField
                  required
                  id="children"
                  label="children"
                  value={this.state.children}
                  onChange={this.handleChange("name")}
                  margin="normal"
                  variant="filled"
                /> */}
                <input type="text" name="fname" value={this.state.children} />
                <IconButton
                  aria-label="Delete"
                  onClick={() => {
                    this.handleCountChange("sub", "children");
                  }}
                >
                  <MinusIcon />
                </IconButton>
              </div>
            </Grid>
            <Grid item xs={2}>
              <h3>Rooms</h3>

              <div className="incrementer-box">
                <IconButton
                  aria-label="Delete"
                  onClick={() => {
                    this.handleCountChange("add", "count");
                  }}
                >
                  <AddIcon />
                </IconButton>
                {/* <TextField
                  required
                  id="rooms"
                  label="Rooms"
                  value={this.state.rooms}
                  onChange={this.handleChange("name")}
                  margin="normal"
                  variant="filled"
                /> */}
                <input type="text" name="fname" value={this.state.count} />
                <IconButton
                  aria-label="Delete"
                  onClick={() => {
                    this.handleCountChange("sub", "count");
                  }}
                >
                  <MinusIcon />
                </IconButton>
              </div>
            </Grid>
            <Grid item xs={6} className="preference-row">
              <h3>Rate Preference</h3>
              <input/>
            </Grid>
          </Grid>
          <div className="search-btn-home">
            <NavLink to="/hotelsearchresult">
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  action.fetchHotelSearchResult(this.state);
                }}
              >
                {/* //<img src={icons.searchBtnIcon} className="search-btn-img" />{" "} */}
                Search
              </Button>
            </NavLink>
          </div>
        </MuiPickersUtilsProvider>
      </div>
    );
  }
}
