import React from 'react';

export const AdvancedSearchResultComponent = props => {  
    return(
       <div>Advanced Search Result</div>
    )
}